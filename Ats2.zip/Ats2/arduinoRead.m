function arduinoRead (arduino)
%this code will read a button on an arduino
stop = evalin('base','Stop') ;

if ~readDigitalPin(arduino,'D13')
    if stop == false
    assignin('base','Stop',true) 
    assignin('base','Go',false)
    disp('stop')
    end 
    if stop == true
        assignin('base','Stop',false) 
        assignin('base','Go',true)
        disp('go')
    end 
end



end