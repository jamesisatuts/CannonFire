

%% test cannon move
%
 close all 
clear all

position = [ 0 ,0 , 0.35]

cannon = makeObject('CannonBarrel.ply', position);

%%cannon.move(transl(position)*troty(pi/8))

rot = cannon.getPose();

rotm = [rot(1:3,1:3)];


rpy = rotm2eul(rotm);

startAngle  = rpy(2);

CbaseTr = transl([0+0.7 , 0+0.25, 0]);
cr7 = CR7(CbaseTr);

ctr = cr7.model.fkine(cr7.model.getpos()).T*trotx(-pi/2);
            
            
            % CR7 position  

            cx = ctr(1,4);
            cy = ctr(2,4);
            cz = ctr(3,4);

            % Gripper Placement 
            grip1offset = transl(0, -0.035, -0.035)*trotz(pi/2)*troty(pi);
            grip2offset = transl(0.03, -0.035, 0.035)*trotz(-pi/2);
            grip3offset = transl(-0.03, -0.035, 0.035)*trotz(-pi/2);
            
            cgrip1 = Gripper2(ctr*transl(0, -0.035, -0.035)*trotz(pi/2)*troty(pi));
            cgrip2 = Gripper2(ctr*transl(0.03, -0.035, 0.035)*trotz(-pi/2));
            cgrip3 = Gripper2(ctr*transl(-0.03, -0.035, 0.035)*trotz(-pi/2));



cannonMove(cr7,cannon, pi/8,cgrip1,cgrip2,cgrip3);



%% test cannon positioning

close all 
clear all
position = [ 0 ,0 , 0.35]
cannon = makeObject('CannonBarrel.ply', position);

cannon.move(transl(position)*troty(-pi/16))

rot = cannon.getPose();
rotm = [rot(1:3,1:3)];


rpy = rotm2eul(rotm);

startAngle  = rpy(2)

CbaseTr = transl([0+0.7 , 0+0.25, 0]);
cr7 = CR7(CbaseTr);


 transpose = cannon.getPose() ;                       
 transpose = transpose * transl(0.5,0,0)*trotx(pi/2)*troty(-pi/2)


  q0 = deg2rad([45 -72 72 -72 -72 0]); 
 
 q  = cr7.model.ikcon(transpose,q0);

 actualpose = cr7.model.fkine(q)

 cr7.model.animate(q);


