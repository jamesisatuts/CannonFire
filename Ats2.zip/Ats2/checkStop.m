function checkStop(stopButton)
% checks to see if the stop button has been pressed, if so it will wait for
% the resume button to be pressed 
stopped = true;

while evalin('base','Go') ~= true
    if stopped == true 
    disp('Robot has been stopped')    % will write message only once 
    stopped = false;
    drawnow();
    pause(0.1);
    end
    
end 

if stopped == false
 disp('Robot has been resumed')
end
end