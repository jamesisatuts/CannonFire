        function Move_arm(brick_end, brick_grip, r, grip, grip2, grip3, brick, x)

            filename = 'LinearUR3Position.log'
            L =  log4matlab(filename);

            % Variable to get the current position
            current = r.model.getpos();
            % Transformation matrix from current to the brick X location
            t1 = transl(brick_grip)* transl([0,0,0.2]) * trotx(pi);

            % Defining elbow up to prevent collision to table,
            % found with L UR3 teach
            elbow_up = deg2rad([0 0 65 50 -35 -50 0]);
            % Getting the joint angle based on end location
            q_end = r.model.ikcon(t1, elbow_up);

            % Q pose for up
            
            steps = 100;
            % Using trajectory command, to get from current to end pose in
            % 100 steps
            traj = jtraj(current, q_end, steps);


            % Using a for loop to animate the arm getting from current to
            % grab brick pose

            [f,v,data] = plyread('Brick.ply','tri');

            Colours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;

            Vertex = size(v,1);
            
            BrickMove = trisurf(f,v(:,1)+brick(1,1),v(:,2)+brick(1,2), v(:,3)+brick(1,3) ...
                ,'FaceVertexCData',Colours,'EdgeColor','none','EdgeLighting','none');

                for i = 1 : size(traj,1)

                    r.model.animate(traj(i,:));
                    %matrix gets the x, y, z coordinates
                    matrix = traj(i, :);
                    %end effector is found by getting the translation
                    %matrix using fkine to the trajectory matrix from above
                    %that determines the end pose
                    endEffector = transl(r.model.fkine(matrix))';
                    %L.mlog helps log the position of where it is
                    L.mlog = {L.DEBUG, 'EndEff', endEffector};


                    % To prevent rapid Logging of the end effector using
                    % modulus to log 10 times per 100 steps
                    a = 0;
                    if a == mod(i, 10)
                        disp('Current end pos to brick:')
                        disp(endEffector);
                    end

                    %tip is used to get the end effector location that is
                    %then used to plot the fingers base to the end effector
                    %and transform them accordingly.
                    tip = r.model.fkine(matrix).T;
                    % Calculate the tip transformation
                    grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);
                    %finger is then animated.
                    grip.model.animate([0 0]);
                    grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                    grip2.model.animate([0 0]);


                    grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                    grip3.model.animate([0 0]);

                    pause(0.02);
                end

                %%
                
                current = r.model.getpos();
                % Transformation matrix from current to the brick X location
                t1 = transl(brick_grip) * trotx(pi);
    
                % Defining elbow up to prevent collision to table,
                % found with L UR3 teach
                elbow_up = deg2rad([0 0 65 50 -35 -50 0]);
                % Getting the joint angle based on end location
                q_end = r.model.ikcon(t1, elbow_up);
    
                % Q pose for up
                
                steps = 100;
                % Using trajectory command, to get from current to end pose in
                % 100 steps
                traj = jtraj(current, q_end, steps);

                for i = 1 : size(traj,1)

                    r.model.animate(traj(i,:));
                    %matrix gets the x, y, z coordinates
                    matrix = traj(i, :);
                    %end effector is found by getting the translation
                    %matrix using fkine to the trajectory matrix from above
                    %that determines the end pose
                    endEffector = transl(r.model.fkine(matrix))';
                    %L.mlog helps log the position of where it is
                    L.mlog = {L.DEBUG, 'EndEff', endEffector};


                    % To prevent rapid Logging of the end effector using
                    % modulus to log 10 times per 100 steps
                    a = 0;
                    if a == mod(i, 10)
                        disp('Current end pos to brick:')
                        disp(endEffector);
                    end

                    %tip is used to get the end effector location that is
                    %then used to plot the fingers base to the end effector
                    %and transform them accordingly.
                    tip = r.model.fkine(matrix).T;
                    % Calculate the tip transformation
                    grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);
                    %finger is then animated.
                    grip.model.animate([0 0]);
                    grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                    grip2.model.animate([0 0]);


                    grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                    grip3.model.animate([0 0]);

                    %Closes the gripper when endEffector is false, hence
                    %above the brick
                    if endEffector == false

                        grip.model.animate([pi/12 pi/12]);
                        grip2.model.animate([pi/12 pi/12]);
                        grip3.model.animate([pi/12 pi/12]);
                    end

                    pause(0.02);
                end

                %%
                % Robot has reached brick to pick up, can show brick at end effector
                % Current position of the end effector
                


                current = r.model.getpos();
                % getting a transoformation matrix for the brick and its
                % rotated about the x axis
                T2 = transl(brick_end)*transl([0,0,0.15]) * trotx(pi);
                

                elbow_up_end = deg2rad([0 180 65 50 -35 -50 0]);
                brick_end = r.model.ikcon(T2, elbow_up_end);
               


                traj_end = jtraj(current, brick_end, steps);
                

                try delete(x);
                catch anything
                end
                


                for i = 1:steps
                    % Calc position of the brick at the end effector
                    t = r.model.fkine(traj_end(i,:)).T;
                    r.model.animate(traj_end(i,:));
                    %using the logging function provided to us by Gavin
                    %message is the x y z of end effector
                    matrix = traj_end(i, :);
                    endEffector = transl(r.model.fkine(matrix))';
                    L.mlog = {L.DEBUG, 'EndEff', endEffector};
                    a = 0;
                    if a == mod(i, 10)
                        disp('Current end pos to drop off:')
                        disp(endEffector);
                    end

                    tip =  r.model.fkine(matrix).T;
                    %Displaced by 0.1 in z so bricks appear to be grabbed
                    %by the tip of the gripper
                    Bpose = tip*transl(0,0,0.1) ;
                    %This moves the brick to the NewPose, multiplies the pose to vertices
                    NewPose = [Bpose * [v,ones(Vertex,1)]']';
                    %The vertices are all the rows and 1 to 3 columns of the UpdatedPoint
                    BrickMove.Vertices = NewPose(:,1:3);
                    grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);
                    %finger is then animated.
                    grip.model.animate([pi/12 pi/12]);
                    grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                    grip2.model.animate([pi/12 pi/12]);


                    grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                    grip3.model.animate([pi/12 pi/12]);

                    %Closes the gripper when endEffector is false, hence
                    %above the brick
                    if endEffector == false

                        grip.model.animate([0 0]);
                        grip2.model.animate([0 0]);
                        grip3.model.animate([0 0]);
                    end
                    pause(0.02);
                end
            end