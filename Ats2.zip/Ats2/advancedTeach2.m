function advancedTeach(robot)
    id = 1; 
    joy = vrjoystick(id);
    caps(joy); %don't need to display this right now 

    q = robot.model.getpos();
    
    robot.model.delay = 0.001; % lower delay for a faster animation 

    duration = 250 ; %sets time for simulation 
    tic; 
    stepCount = 0; %initial step count 

    simulationTime = 0.15;


    while(toc < duration)
        stepCount = stepCount + 1 ; %increment step count
        [axes, buttons, povs] = read(joy);

        fx = axes(1);
        fy = 0;
        fz = 0;
        
        tx = 0;
        ty = axes(3);
        tz = 0;
        
        f = [fx;fy;fz;tx;ty;tz]; % combined force-torque vector (wrench)
        
        % 2 - use simple admittance scheme to convert force measurement into
        % velocity command
        Ka = diag([0.3 0.3 0.3 0.5 0.5 0.5]); % admittance gain matrix  
        dx = Ka*f; % convert wrench into end-effector velocity command
        
        % 2 - use DLS J inverse to calculate joint velocity
        J = robot.model.jacobe(q);
        
        lambda = 0.1;
        Jinv_dls = inv((J'*J)+lambda^2*eye(8))*J';
        dq = Jinv_dls*dx;

        % apply joint velocity 
        q = q +dq'*simulationTime
        q = [0 q(2:8)]

        robot.model.animate(q);

        while (toc <simulationTime*stepCount)  %waits for loops to finshe 
        end
    end 


end