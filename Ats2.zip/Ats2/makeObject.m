classdef makeObject < handle
    %OBJECT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        faceData;
        vertexData;
        data; 
        vertexSize;
        obj;
        updatePose ;
        Pose;
        vertexColours;
    end
    
    methods
        %% making the object 
        function self = makeObject( plyFile, position)
            self.Pose = transl(position(1), position(2), position(3));
            hold on;
   
            self.updatePose = zeros(4,4)
            [self.faceData, self.vertexData, self.data] = plyread(plyFile,'tri');  % Reads in the object
            self.vertexSize = size(self.vertexData,1);
            self.vertexColours = [self.data.vertex.red, self.data.vertex.green, self.data.vertex.blue ]/255; % Reads in the colours

            % creates the object
            self.obj = trisurf(self.faceData,self.vertexData(:,1)+position(1),self.vertexData(:,2)+position(2),self.vertexData(:,3)+position(3), 'FaceVertexCData',self.vertexColours, 'EdgeLighting', ' flat' );
            disp('New object placed')
        end

       %% move the object 
        function move(self, positionTranspose)
            self.Pose = positionTranspose;  % Changes the variables 
            
            self.updatePose = [positionTranspose * [self.vertexData,ones(self.vertexSize,1)]']';
            self.obj.Vertices = self.updatePose(:,1:3);
            
        end
    

        
        %% finding the object 
        function pose = getPose(self)
            pose = self.Pose;
        end

        
        
    end
end

