function Fence()
concrete();
h_1 = PlaceObject('barrier1.5x0.2x1m.ply',[0,-1.8,0]);
            verts = [get(h_1,'Vertices'), ones(size(get(h_1,'Vertices'),1),1)] ;
            verts(:,1) = verts(:,1) * 2;
            set(h_1,'Vertices',verts(:,1:3))

            h_2 = PlaceObject('barrier1.5x0.2x1m.ply',[0,1.8,0]);
            verts = [get(h_2,'Vertices'), ones(size(get(h_2,'Vertices'),1),1)] ;
            verts(:,1) = verts(:,1) * 2;
            set(h_2,'Vertices',verts(:,1:3))

            h_3 = PlaceObject('barrier1.5x0.2x1m.ply',[-0.1,0,0]);
            verts = [get(h_3,'Vertices'), ones(size(get(h_3,'Vertices'),1),1)] * trotz(pi/2);
            verts(:,2) = verts(:,2) * 2;
            verts(:,1) = verts(:,1) + 2;
            set(h_3,'Vertices',verts(:,1:3))

            %h_4 = PlaceObject('barrier1.5x0.2x1m.ply',[-0.1,0,0]);
            %verts = [get(h_4,'Vertices'), ones(size(get(h_4,'Vertices'),1),1)] * trotz(pi/2);
            %verts(:,2) = verts(:,2) * 2;
            %verts(:,1) = verts(:,1) - 2;
            %set(h_4,'Vertices',verts(:,1:3))
end