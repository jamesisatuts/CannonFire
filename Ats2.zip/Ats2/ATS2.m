
classdef ATS2 < handle

    methods

        function self = ATS2()
            clf
            clc
            self.setup();
            
            while true
           
                
            options = Input('Type which code do you wish to run, ontroller, simulation, exit');
            if options == 'controller'
                self.controller();
            elseif options == 'simulation'
                    self.simulation();
            elseif options == 'exit'
                break
            else
                disp('That input was invalid')
            end
            end
           
            
        end
    end




    methods(Static)


        function setup()
            close all;
            clc;
            
            %% Used for changing the object locations all at once
            x = -0.2;
            X = x;

            y = 0.1;
            Y = y;

            z = 0;
            Z = z;

            
            Bx = 0;
            By = 0;
            Bz = 0;

            %% Plotting the intial scene
                        % place_table = [0,0.5,0];
            place_cannon = [0, 0, 0.35];
            

            % Refers to a function to plotting the concrete jpg'
            concrete();

            %% place cannon
            Cannon = makeObject('CannonBarrel.ply',place_cannon);
            Stand = makeObject('CannonStand.ply',place_cannon);
                        % PlaceObject('tableBrown2.1x1.4x0.5m.ply', place_table);
            Fence();
            

            %% LinearUR10 initalise and using
            baseTr = transl([Bx-1.5, By+1, Bz])*trotz(pi/2);
            r = LinearUR10(baseTr);
            tr = r.model.fkine(r.model.getpos);
            tr2 = r.model.fkine(r.model.getpos).T;
            Start = r.model.fkine(r.model.getpos).T;

            

            % Getting the coordinates for the x y z axis
            xcord = tr2(1, 4);
            ycord = tr2(2, 4);
            zcord = tr2(3, 4);

            % Gripper initalisation
            grip = Gripper2(transl(xcord, ycord-0.035, zcord-0.035)*trotz(pi/2)*troty(pi));
            grip2 = Gripper2(transl(xcord+0.03, ycord-0.035, zcord+0.035)*trotz(-pi/2));
            grip3 = Gripper2(transl(xcord-0.03, ycord-0.035, zcord+0.035)*trotz(-pi/2));

            % first link is in meters between -0.8 and -0.01
            q = [0,0,0,0,0,0,0,0];
            r.model.animate(q);

            %% Cr7 initiate 
            % Cr7 initialisation 
          
            CbaseTr = transl([Bx+0.7 , By+0.25, Bz]);
            cr7 = CR7(CbaseTr);
            cr7.model.animate([0 -pi/2 0 0 0 0]);

            

            moveCannon(cr7,Cannon,0);

            Cq0 = deg2rad([45 -72 72 -72 -72 0]);
            moveTr = FindCannonHandle(Cannon)*transl(0.1,0,0)*trotx(pi/2)*troty(-pi/2);

            qnext = cr7.model.ikine(moveTr,Cq0);
            Cq0 = qnext;
            cr7.model.animate(Cq0);
            
            

            ctr = cr7.model.fkine(qnext).T*trotx(-pi/2);
            
            
            % CR7 position  

            cx = ctr(1,4);
            cy = ctr(2,4);
            cz = ctr(3,4);

            % Gripper Placement 
            grip1offset = transl(0, -0.035, -0.035)*trotz(pi/2)*troty(pi);
            grip2offset = transl(0.03, -0.035, 0.035)*trotz(-pi/2);
            grip3offset = transl(-0.03, -0.035, 0.035)*trotz(-pi/2);
            
            cgrip = Gripper2(ctr*transl(0, -0.035, -0.035)*trotz(pi/2)*troty(pi));
            cgrip2 = Gripper2(ctr*transl(0.03, -0.035, 0.035)*trotz(-pi/2));
            cgrip3 = Gripper2(ctr*transl(-0.03, -0.035, 0.035)*trotz(-pi/2));


            %% Objects
            % Position of object 1, to plot, to grab, to place
            Powder = [-0.35,  0.4,  0.045];
            Powder_grip = [-0.35, 0.2, 0.1];
            Powder_end = [-0.5, 0, 0.45];

            % Balls 2
            Ball = [-0.35, 0.6, 0.045];
            Ball_grip = [-0.35, 0.3765, 0.1];
            Ball_end = [-0.5, 0, 0.45];

            % Placing the object .ply files on the table
            x1 = PlaceObject('Powder.ply', Powder);
            x2 = PlaceObject('Ball.ply', Ball);
            
            
            % Waiting for input to start operation, as a means of safety
            input('Press ENTER to start operation...');


            %% Calls the move arm function, that performs movement

            %Perform object 1 movements
            object = Powder;
            x = x1
            object_end = Powder_end;
            object_grip = Powder_grip;
            File = 'Powder.ply';
            ATS2.Move_arm(object_end, object_grip, r, grip, grip2, grip3, object, x, File)

            %Perform object 2 movements
            object = Ball;
            x = x2;
            object_end = Ball_end;
            object_grip = Ball_grip;
            File = 'Ball.ply';
            ATS2.Move_arm(object_end, object_grip, r, grip, grip2, grip3, object, x, File)

            %Press ENTER to end the operation.

            input('Press ENTER to end operation...');

        end

        



        % Controls the movement, takes in goal, end, above goal and above
        % end, positions to perform the 4 movements

        function Move_arm(object_end, object_grip, r, grip, grip2, grip3, object, x, File)

            % Getting current pos of end effector, & offseting goal +z[0.2]
            current = r.model.getpos();
            t1 = transl(object_grip)* transl([0,0,0.2]) * trotx(pi);

            % Defining elbow up to prevent collision to ground,
            elbow_up = deg2rad([0 0 -40 90 40 -90 0 0]);

            % Getting the q translation matrix using, elbow up and t1
            q_end = r.model.ikcon(t1, elbow_up);
            steps = 100;

            % Setting the trajectory, current --> q_end in 100 steps
            traj = jtraj(current, q_end, steps);

            % Closing and opening variable for the grippers
            open = deg2rad([0,15,15,15]);
            close = deg2rad([0,-15,-15,-15]);
            % Using a for loop to animate the arm getting from current to
            % grab object pose

            % Setting up the object object vertices which will be used in moving
            % them later in the code, using code provided by Gavin
            % a = contains faces of the object model
            % b = contains vertices of the 3d model
            % cData holds the colour data
            
            [a,b,cData] = plyread(File,'tri');

            % Normalising the colour, to allow for proper plotting
            Colours = [cData.vertex.red, cData.vertex.green, cData.vertex.blue] / 255;

            % Calculating the size/number of vertices in the 3D model
            Vertex = size(b,1);

            %trisurf, for 3D plot of trainglur elements
            %x coord, y coord, and zcoord of the object positions
            objectMove = trisurf( ...
                a,b(:,1)+object(1,1), ...
                b(:,2)+object(1,2), ...
                b(:,3)+object(1,3) ...
                ,'FaceVertexCData',Colours,'EdgeColor','none','EdgeLighting','none');

            % 1st for loop, from start pos to above object location

            for i = 1 : size(traj,1)

                % Animating the arm to move
                r.model.animate(traj(i,:));
                matrix = traj(i, :);

                % Using the matrix of the trajectory, determining
                % endEffector
                endEffector = transl(r.model.fkine(matrix))';

                % Plot endEffector position every 10 steps
                a = 0;
                if a == mod(i, 10)
                    disp('Current end pos to object:')
                    disp(endEffector);
                end


                % Tip gets endEffector pos, plots fingers to that,
                % transforms accordingly
                tip = r.model.fkine(matrix).T;

                % Finger is then animated at the tip and moves with arm
                grip.model.base = tip*transl(0,0.015,0)*trotx(pi/2);

                % Finger is then animated at the tip and moves with arm
                % left/right = x, Up/down = y, forward/back = z
                grip.model.base = tip*transl(-0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip.model.animate(open);
                grip2.model.base = tip*transl(0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip2.model.animate(open);
                grip3.model.base = tip*transl(0,0.04,0.03)*trotz(pi/2)*troty(-pi/2)*trotx(-pi/2);
                grip3.model.animate(open);

                pause(0.02);
            end

            %%

            % Similar to loop one gets the current, end and the steps to
            % move arm down to the object location
            current = r.model.getpos();
            t1 = transl(object_grip) * trotx(pi);
            elbow_up = deg2rad([0 0 -40 90 40 -90 0 0]);

            % Getting the joint angle based on end location
            q_end = r.model.ikcon(t1, elbow_up);
            steps = 100;

            % Using trajectory command, to get from current to end pose in
            traj = jtraj(current, q_end, steps);
            

            for i = 1 : size(traj,1)
                % Animating the arm to move
                r.model.animate(traj(i,:));
                matrix = traj(i, :);

                % Using the matrix of the trajectory, determining
                % endEffector
                endEffector = transl(r.model.fkine(matrix))';

                % Plot endEffector position every 10 steps
                a = 0;
                if a == mod(i, 10)
                    disp('Current end pos to object:')
                    disp(endEffector);
                end

                % Tip gets endEffector pos, plots fingers to that,
                % transforms accordingly
                tip = r.model.fkine(matrix).T;

                % Calculate the tip transformation
                grip.model.base = tip*transl(0,0.015,0)*trotx(pi/2);
                
                
                % Finger is then animated at the tip and moves with arm
                grip.model.base = tip*transl(-0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip.model.animate(open);
                grip2.model.base = tip*transl(0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip2.model.animate(open);
                grip3.model.base = tip*transl(0,0.04,0.03)*trotz(pi/2)*troty(-pi/2)*trotx(-pi/2);
                grip3.model.animate(open);
                
                
                % Closes the gripper when endEffector is false
                if  endEffector == false
                    grip.model.animate(close);
                    grip2.model.animate(close);
                    grip3.model.animate(close);
                end

                

                pause(0.02);
            end

            %%

            % Loop 3, object pick up and move to above designated location
            % Get the current,
            current = r.model.getpos();

            % getting a transformation matrix for the object and its
            % rotated about the x axis
            T2 = transl(object_end) * transl([0, 0, 0.15]) * trotx(pi);
            elbow_up_end = deg2rad([0 180 65 50 -35 -50 0 0]);
            q_end4 = r.model.ikcon(T2, elbow_up_end);
            traj_end = jtraj(current, q_end4, steps);

            % Deletes the position of the object
            try delete(x);
            catch anything
            end


            for i = 1:steps

                % Calc position of the object at the end effector
                t = r.model.fkine(traj_end(i,:)).T;
                r.model.animate(traj_end(i,:));

                % Using the logging function provided to us by Gavin
                % message is the x y z of end effector
                matrix = traj_end(i, :);
                endEffector = transl(r.model.fkine(matrix))';
                a = 0;

                % Display the end effector position every 10 steps
                if a == mod(i, 10)
                    disp('Current end pos to drop off:')
                    disp(endEffector);
                end

                tip =  r.model.fkine(matrix).T;

                % Displaced by 0.1 in z so the object appears to be grabbed
                % at the tip of the gripper
                Bpose = tip*transl(0,0,0.1);

                % This moves the object to the NewPose, multiplies the pose to vertices
                NewPose = [Bpose * [b,ones(Vertex,1)]']';

                % The vertices are all the rows and 1 to 3 columns of the UpdatedPoint
                objectMove.Vertices = NewPose(:,1:3);
                
                grip.model.base = tip*transl(0,0.015,0)*trotx(pi/2);

                grip.model.base = tip*transl(-0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip.model.animate(close);
                grip2.model.base = tip*transl(0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip2.model.animate(close);
                grip3.model.base = tip*transl(0,0.04,0.03)*trotz(pi/2)*troty(-pi/2)*trotx(-pi/2);
                grip3.model.animate(close);
                

                % Opens the gripper when endEffector is false
                if endEffector == false
                    grip.model.animate(open);
                    grip2.model.animate(open);
                    grip3.model.animate(open);
                end

                pause(0.02);

            end

            %%

            % For loop 4, moving from up above final to final destination
            % Delete the object from the up location above the intended
            % destination

            try delete(x);
            catch anything
            end

            % Get the current location, the end location and a translation
            % matrix to transfer the object to
            current = r.model.getpos();

            % getting a transoformation matrix for the object and its
            % rotated about the x axis
            T2 = transl(object_end)*troty(pi);
            steps =100;
            elbow_up_end = deg2rad([0 180 -40 90 40 -90 0 0]);
            object_end = r.model.ikcon(T2, elbow_up_end);

            % Setting trajectory of current, object end, and steps
            traj_end = jtraj(current, object_end, steps);

            for i = 1:steps

                % Calc position of the object at the end effector
                t = r.model.fkine(traj_end(i,:)).T;
                r.model.animate(traj_end(i,:));

                %using the logging function provided to us by Gavin
                %message is the x y z of end effector
                matrix = traj_end(i, :);
                endEffector = transl(r.model.fkine(matrix))';
                a = 0;

                % Display end effector position at every 10 steps
                if a == mod(i, 10)
                    disp('Current end pos to drop off:')
                    disp(endEffector);
                end

                tip =  r.model.fkine(matrix).T;

                %Displaced by 0.1 in z so object appear to be grabbed
                %by the tip of the gripper
                Bpose = tip*transl(0,0,0.1) ;

                %This moves the object to the NewPose, multiplies the pose to vertices
                NewPose = [Bpose * [b,ones(Vertex,1)]']';

                %The vertices are all the rows and 1 to 3 columns of the UpdatedPoint
                objectMove.Vertices = NewPose(:,1:3);
                grip.model.base = tip*transl(0,0.015,0)*trotx(pi/2);

                %finger is then animated.
                grip.model.base = tip*transl(-0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip.model.animate(close);
                grip2.model.base = tip*transl(0.04,-0.04,0.03)*troty(-pi/2)*trotx(-pi);
                grip2.model.animate(close);
                grip3.model.base = tip*transl(0,0.04,0.03)*trotz(pi/2)*troty(-pi/2)*trotx(-pi/2);
                grip3.model.animate(close);

                % Open end claw when endEffector and let go of the object.
                if endEffector == false
                    grip.model.animate(open);
                    grip2.model.animate(open);
                    grip3.model.animate(open);
                end
                pause(0.02);
            end
        end

        
        
        
    end
end


