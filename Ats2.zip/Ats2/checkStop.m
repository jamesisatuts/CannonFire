function checkStop(stopButton,a)
% checks to see if the stop button has been pressed, if so it will wait for
% the resume button to be pressed 
stopped = true;

stop = evalin('base','Stop') ;

while stop == true
    
    disp('Robot has been stopped')    % will write message only once 
    stopped = false;
    drawnow();
    arduinoRead(a);
    stop = evalin('base','Stop') ;
    pause(1);
    
    
end 

if stopped == false
 disp('Robot has been resumed')
end
end