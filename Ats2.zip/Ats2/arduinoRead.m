function arduinoRead (arduino)
%this code will read a button on an arduino


if ~readDigitalPin(arduino,'D13')
    assignin('base','Stop',true) 
    assignin('base','Go',false)
    disp('stop')
end



end