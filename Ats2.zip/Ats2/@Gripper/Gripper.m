classdef Gripper < RobotBaseClass
    %% UR3 Universal Robot 3kg payload robot model
    %
    % WARNING: This model has been created by UTS students in the subject
    % 41013. No guarentee is made about the accuracy or correctness of the
    % of the DH parameters of the accompanying ply files. Do not assume
    % that this matches the real robot!

    properties(Access = public)   
        plyFileNameStem = 'Gripper';
    end
    
    methods
%% Constructor
        function self = Gripper(baseTr,useTool,toolFilename)
            if nargin < 3
                if nargin == 2
                    error('If you set useTool you must pass in the toolFilename as well');
                elseif nargin == 0 % Nothing passed
                    baseTr = transl(0,0,0);  
                end             
            else % All passed in 
                self.useTool = useTool;
                toolTrData = load([toolFilename,'.mat']);
                self.toolTr = toolTrData.tool;
                self.toolFilename = [toolFilename,'.ply'];
            end
          
            self.CreateModel();
            
			self.model.base = self.model.base.T * baseTr;
            self.model.tool = self.toolTr;
            self.PlotAndColourRobot();

            drawnow
        end

%% CreateModel
        function CreateModel(self)
            %Need only 2 links for the fingers on the gripper d = 0, x = 

            %need to add a base, 
            link(1) = Link('d',0.04,'a',-0.035,'alpha',0,'qlim',deg2rad([0 0]), 'offset',0);
            link(2) = Link('d',0,'a',-0.04,'alpha',pi,'qlim', deg2rad([-360 360]), 'offset',0);
            link(3) = Link('d',-0.09,'a',-0.005,'alpha',0,'qlim', deg2rad([-360 360]), 'offset',0);
            link(4) = Link('d',-0.035,'a',-0.008,'alpha',0,'qlim', deg2rad([-360 360]), 'offset', 0);
            %link(5) = Link('d',0,'a',0.05,'alpha',0,'qlim', deg2rad([-360 360]), 'offset', 0);
            % link(6) = Link('d',0.0819,'a',0,'alpha',0,'qlim',deg2rad([-360,360]), 'offset', 0);
             
            self.model = SerialLink(link,'name',self.name);
        end  

       
    end
end
