function handle = FindCannonHandle(cannon)
            currentPose = cannon.getPose();
            handle  = currentPose*transl(0.4,0,0);
        
end 

