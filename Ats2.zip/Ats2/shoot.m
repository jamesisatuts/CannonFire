function shoot(ball,cannon)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

ball.move()

end