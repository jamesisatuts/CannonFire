
function moveCannon(robot,cannon,startAngle,endAngle)
            q0 = deg2rad([45 -72 72 -72 -72 0]);
            moveTr = FindCannonHandle(cannon)*transl(0.1,0,0)*trotx(pi/2)*troty(-pi/2);

            steps = 40 

            stepSize = startAngle-endAngle 

            movement = startAngle + (startAngle-endAngle)
           

            qnext = robot.model.ikine(moveTr,q0);
            q0 = qnext;
            robot.model.animate(q0);

         
            
end
