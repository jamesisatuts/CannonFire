classdef runner  < handle 
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here

    properties
        Property1
    end

    methods
        function self = runner()
            close all 
            clear all
            
            %% Setup the enviroment 
            
            concrete();
            Fence();
            try 
                arduinoRead(arduino);
            end
            
            % Cannon
            cannonPosition = [0 0 0.35];
            cannonBarrel = makeObject('cannonBarrel.ply', cannonPosition);
            cannonStand = makeObject('cannonStand.ply', cannonPosition);

            % powder and cannon ball 
            powder  = makeObject('Powder.ply', [-0.35,  0.4,  0.045]);

            cannonBall = makeObject('Ball.ply', [-0.35, 0.6, 0.045]);

            %% Stop button
            stopButton = StopButtono;

             
                
            %% Linear Ur10 initialise
            baseTr = transl([-1.5, 1, 0])*trotz(pi/2);
            r = LinearUR10(baseTr);
            tr = r.model.fkine(r.model.getpos);
            tr2 = r.model.fkine(r.model.getpos).T;
            Start = r.model.fkine(r.model.getpos).T;

            

            % Getting the coordinates for the x y z axis
            xcord = tr2(1, 4);
            ycord = tr2(2, 4);
            zcord = tr2(3, 4);

            % Gripper initalisation
            grip = Gripper2(transl(xcord, ycord-0.035, zcord-0.035)*trotz(pi/2)*troty(pi));
            grip2 = Gripper2(transl(xcord+0.03, ycord-0.035, zcord+0.035)*trotz(-pi/2));
            grip3 = Gripper2(transl(xcord-0.03, ycord-0.035, zcord+0.035)*trotz(-pi/2));

            % first link is in meters between -0.8 and -0.01
            q = [0,0,0,0,0,0,0,0];
            r.model.animate(q);
           

            %% Cr7 initialise

            CbaseTr = transl([0.7 , 0.25, 0]);
            cr7 = CR7(CbaseTr);
            cr7.model.animate([0 -pi/2 0 0 0 0]);

            
            Cq0 = deg2rad([45 -72 72 -72 -72 0]);
            moveTr = FindCannonHandle(cannonBarrel)*transl(0.1,0,0)*trotx(pi/2)*troty(-pi/2);
            qnext = cr7.model.ikine(moveTr,Cq0);
            Cq0 = qnext;
            cr7.model.animate(Cq0);
            ctr = cr7.model.fkine(qnext).T*trotx(-pi/2);

            % CR7 position  

            cx = ctr(1,4);
            cy = ctr(2,4);
            cz = ctr(3,4);

            % Gripper Placement 
            grip1offset = transl(0, -0.035, -0.035)*trotz(pi/2)*troty(pi);
            grip2offset = transl(0.03, -0.035, 0.035)*trotz(-pi/2);
            grip3offset = transl(-0.03, -0.035, 0.035)*trotz(-pi/2);
            
            cgrip1 = Gripper2(ctr*transl(0, -0.035, -0.035)*trotz(pi/2)*troty(pi));
            cgrip2 = Gripper2(ctr*transl(0.03, -0.035, 0.035)*trotz(-pi/2));
            cgrip3 = Gripper2(ctr*transl(-0.03, -0.035, 0.035)*trotz(-pi/2));

            %% Movement 
            
            input('are you ready to start cannon move')
            cannonMove(cr7,cannonBarrel,-pi/16,cgrip1,cgrip2,cgrip3,stopButton,arduino);
            input('are you ready to start Teach')
            advancedTeach(r);
            delete(stopButton);



        end

        
    end
end