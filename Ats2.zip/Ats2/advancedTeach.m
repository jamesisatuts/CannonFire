function advancedTeach(robot)
    id = 1; 
    joy = vrjoystick(id);
    caps(joy); %don't need to display this right now 

    q = robot.model.getpos();
    
    robot.model.delay = 0.001; % lower delay for a faster animation 

    duration = 250 ; %sets time for simulation 
    tic; 
    stepCount = 0; %initial step count 

    simulationTime = 0.15;


    while(toc < duration)
        stepCount = stepCount + 1 ; %increment step count
        [axes, buttons, povs] = read(joy);

        linearVelocity = 0.3;
        angularVelocity = 1;

        vx = linearVelocity*axes(1);
        vy = linearVelocity*axes(2);
        vz = linearVelocity*(buttons(5)-buttons(7));
        wx = angularVelocity*axes(4);
        wy = angularVelocity*axes(3);
        wz = angularVelocity*(buttons(6)-buttons(8));

        dx = [vx;vy;wx;wy;vz;wz] % combined velocity 

        %calculate joint velocity 
        
        
        lambda = 0.5;
        jacob = robot.model.jacob0(q);
        Jinv_dls = inv((jacob'*jacob)+lambda^2*eye(8))*jacob';
        dq = Jinv_dls*dx;


        % apply joint velocity 
        q = q +dq'*simulationTime
        q = [0 q(2:8)]

        robot.model.animate(q);

        while (toc <simulationTime*stepCount)  %waits for loops to finshe 
        end
    end 


end