classdef ATS1_Arya_Nooralizadeh_24577254 < handle

    methods

        function self = ATS1_Arya_Nooralizadeh_24577254()
            clf
            clc
            self.Task1();
            % self.VolCloud();
        end
    end

    methods(Static)

        function Task1()
            close all;
            clc;

            % Used for changing the brick locations all at once
            x = 0;
            X = x;

            y = 0;
            Y = y;

            z = 0;
            Z = z;

            Bx = 0;
            By = 0;
            Bz = 0;

            % Plotting the intial scene

            place_table = [0,0.5,0];
            place_extin = [-1.8, -1.8, 0];
            place_button = [1.8, 1.8, 0];

            % Refers to a function to plotting the concrete jpg'
            concrete();
            PlaceObject('emergencyStopButton.ply', place_button);
            PlaceObject('fireExtinguisher.ply', place_extin);
            PlaceObject('tableBrown2.1x1.4x0.5m.ply', place_table);
            Fence();


            %LinearUR3 initalise and using

            baseTr = transl([Bx, By, 0.5+Bz])
            r = LinearUR3(baseTr);
            tr = r.model.fkine(r.model.getpos);
            tr2 = r.model.fkine(r.model.getpos).T;

            % Getting the coordinates for the x y z axis
            xcord = tr2(1, 4);
            ycord = tr2(2, 4);
            zcord = tr2(3, 4);

            % Gripper initalisation
            grip = Gripper(transl(xcord, ycord, zcord));
            grip2= Gripper(transl(xcord, ycord, zcord)*troty(pi));
            grip3= Gripper(transl(xcord, ycord, zcord)*troty(pi));

            % first link is in meters between -0.8 and -0.01
            q = [0,0,0,0,0,0,0];
            r.model.animate(q);

            % Position of bricks 1 - 9, to plot, to grab, to place
            brick1 = [0.37+x,  0.2+y,  0.5+z];
            brick1_grip = [0.35+x, 0.2+y, 0.64+z];
            brick1_end = [-0.50+x, 0+y, 0.64+z];

            % brick 2
            brick2 = [0.35+x, 0.3765+y, 0.5+z];
            brick2_grip = [0.35+x, 0.3765+y, 0.64+z];
            brick2_end = [-0.50+x, 0.1265+y, 0.64+z];

            % brick 3
            brick3 = [0.35+x, 0.553+y, 0.5+z];
            brick3_grip = [0.35+x, 0.553+y, 0.64+z];
            brick3_end = [-0.50+x, 0.253+y, 0.64+z];

            % brick 4
            brick4 = [0.45+x, 0.2+y, 0.5+z];
            brick4_grip = [0.45+x, 0.2+y, 0.64+z];
            brick4_end = [-0.50+x, 0+y, 0.67+z];

            % brick 5
            brick5 = [0.45+x, 0.3765+y, 0.5+z];
            brick5_grip = [0.45+x, 0.3765+y, 0.64+z];
            brick5_end = [-0.50+x, 0.1265+y, 0.67+z];

            % brick 6
            brick6 = [0.45+x, 0.553+y, 0.5+z];
            brick6_grip = [0.45+x, 0.553+y, 0.64+z];
            brick6_end = [-0.50+x, 0.253+y, 0.67+z];

            % brick 7
            brick7 = [0.55+x, 0.2+y, 0.5+z];
            brick7_grip = [0.55+x, 0.2+y, 0.64+z];
            brick7_end = [-0.50+X, 0+y, 0.70+z];

            % brick 8
            brick8 = [0.55+x, 0.3765+y, 0.5+z];
            brick8_grip = [0.55+x, 0.3765+y, 0.64+z];
            brick8_end = [-0.50+x, 0.1265+y, 0.70+z];

            % brick 9
            brick9 = [0.55+x, 0.553+y, 0.5+z];
            brick9_grip = [0.55+x, 0.553+y, 0.64+z];
            brick9_end = [-0.50+x, 0.253+y, 0.70+z];

            % Placing the brick .ply files on the table
            x1 = PlaceObject('Brick.ply', brick1);
            x2 = PlaceObject('Brick.ply', brick2);
            x3 = PlaceObject('Brick.ply', brick3);
            x4 = PlaceObject('Brick.ply', brick4);
            x5 = PlaceObject('Brick.ply', brick5);
            x6 = PlaceObject('Brick.ply', brick6);
            x7 = PlaceObject('Brick.ply', brick7);
            x8 = PlaceObject('Brick.ply', brick8);
            x9 = PlaceObject('Brick.ply', brick9);

            % Waiting for input to start operation, as a means of safety

            input('Press ENTER to start operation...');


            % Calls the move arm function, that performs move based on
            % bricks

            %Perform brick 1 movements
            brick = brick1;
            x = x1
            brick_end = brick1_end;
            brick_grip = brick1_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2, grip3, brick, x)

            %Perform brick 2 movements
            brick = brick2;
            x = x2;
            brick_end = brick2_end;
            brick_grip = brick2_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2, grip3,brick, x)

            %Perform brick 3 movements
            brick = brick3;
            x = x3;
            brick_end = brick3_end;
            brick_grip = brick3_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2, grip3,brick , x)

            %Perform brick 4 movements
            brick = brick4;
            x = x4;
            brick_end = brick4_end;
            brick_grip = brick4_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2, grip3,brick, x)

            %Perform brick 5 movements
            brick = brick5;
            x = x5;
            brick_end = brick5_end;
            brick_grip = brick5_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2 , grip3,brick, x)

            %Perform brick 6 movements
            brick = brick6;
            x = x6;
            brick_end = brick6_end;
            brick_grip = brick6_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2, grip3,brick, x)

            %Perform brick 7 movements
            brick = brick7;
            x = x7;
            brick_end = brick7_end;
            brick_grip = brick7_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2 , grip3,brick, x)

            %Perform brick 8 movements
            brick = brick8;
            x = x8;
            brick_end = brick8_end;
            brick_grip = brick8_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2,grip3, brick, x)

            %Perform brick 9 movements
            brick = brick9;
            x = x9;
            brick_end = brick9_end;
            brick_grip = brick9_grip;
            ATS1_Arya_Nooralizadeh_24577254.Move_arm(brick_end, brick_grip, r, grip, grip2, grip3,brick, x)

            %Press ENTER to end the operation.

            input('Press ENTER to end operation...');

        end



        %This function controls the movement of the UR3
        %Takes in a brick_end array which has the end position of the brick
        %Takes in a brick_grasp array which is where the end effector should be

        function Move_arm(brick_end, brick_grip, r, grip, grip2, grip3, brick, x)

            filename = 'LinearUR3Position.log'
            L =  log4matlab(filename);

            % Variable to get the current position, going 0.2 offset to
            % brick Pos

            current = r.model.getpos();
            t1 = transl(brick_grip)* transl([0,0,0.2]) * trotx(pi);

            % Defining elbow up to prevent collision to table,
            % found with L UR3 teach

            elbow_up = deg2rad([0 0 65 50 -35 -50 0]);

            % Getting the q translation matrix using, elbow up and t1
            q_end = r.model.ikcon(t1, elbow_up);

            steps = 100;

            % Setting the trajectory, current --> q_end in 100 steps
            traj = jtraj(current, q_end, steps);


            % Using a for loop to animate the arm getting from current to
            % grab brick pose

            % Setting up the brick vertices which will be used in moving
            % them later in the code, using code provided by Gavin

            % a = contains faces of the Brick model
            % b = contains vertices of the 3d model
            % cData holds the colour data
            [a,b,cData] = plyread('Brick.ply','tri');

            % Normalising the colour, to allow for proper plotting
            Colours = [cData.vertex.red, cData.vertex.green, cData.vertex.blue] / 255;

            % Calculating the size/number of vertices in the 3D model

            Vertex = size(b,1);

            %trisurf, for 3D plot of trainglur elements
            %x coord, y coord, and zcoord of the brick positions

            BrickMove = trisurf( ...
                a,b(:,1)+brick(1,1), ...
                b(:,2)+brick(1,2), ...
                b(:,3)+brick(1,3) ...
                ,'FaceVertexCData',Colours,'EdgeColor','none','EdgeLighting','none');

            % 1st for loop, from start pos to above brick location

            for i = 1 : size(traj,1)

                % Animating the arm to move

                r.model.animate(traj(i,:));
                matrix = traj(i, :);

                % Using the matrix of the trajectory, determining
                % endEffector

                endEffector = transl(r.model.fkine(matrix))';

                % L.mlog helps log the position of where it is
                L.mlog = {L.DEBUG, 'EndEff', endEffector};

                % Plot endEffector position every 10 steps
                a = 0;
                if a == mod(i, 10)
                    disp('Current end pos to brick:')
                    disp(endEffector);
                end

                % Tip gets endEffector pos, plots fingers to that,
                % transforms accordingly

                tip = r.model.fkine(matrix).T;

                % Calculate the tip transformation

                grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);

                % Finger is then animated at the tip and moves with arm

                grip.model.animate([pi/20 pi/20]);
                grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                grip2.model.animate([pi/20 pi/20]);
                grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                grip3.model.animate([pi/20 pi/20]);

                pause(0.02);
            end

            %%

            % Similar to loop one gets the current, end and the steps to
            % move arm down to the brick location

            current = r.model.getpos();
            t1 = transl(brick_grip) * trotx(pi);
            elbow_up = deg2rad([0 0 65 50 -35 -50 0]);

            % Getting the joint angle based on end location

            q_end = r.model.ikcon(t1, elbow_up);

            steps = 100;

            % Using trajectory command, to get from current to end pose in

            traj = jtraj(current, q_end, steps);

            for i = 1 : size(traj,1)

                % Animating the arm to move

                r.model.animate(traj(i,:));
                matrix = traj(i, :);

                % Using the matrix of the trajectory, determining
                % endEffector

                endEffector = transl(r.model.fkine(matrix))';

                % L.mlog helps log the position of where it is
                L.mlog = {L.DEBUG, 'EndEff', endEffector};

                % Plot endEffector position every 10 steps
                a = 0;
                if a == mod(i, 10)
                    disp('Current end pos to brick:')
                    disp(endEffector);
                end

                % Tip gets endEffector pos, plots fingers to that,
                % transforms accordingly

                tip = r.model.fkine(matrix).T;

                % Calculate the tip transformation

                grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);

                % Finger is then animated at the tip and moves with arm

                grip.model.animate([pi/20 pi/20]);
                grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                grip2.model.animate([pi/20 pi/20]);
                grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                grip3.model.animate([pi/20 pi/20]);

                % Closes the gripper when endEffector is false

                if endEffector == false
                    grip.model.animate([pi/12 pi/12]);
                    grip2.model.animate([pi/12 pi/12]);
                    grip3.model.animate([pi/12 pi/12]);
                end

                pause(0.02);
            end

            %%

            % Loop 3, brick pick up and move to above designated location

            % Get the current,

            current = r.model.getpos();

            % getting a transformation matrix for the brick and its
            % rotated about the x axis

            T2 = transl(brick_end) * transl([0, 0, 0.15]) * trotx(pi);
            elbow_up_end = deg2rad([0 180 65 50 -35 -50 0]);
            q_end4 = r.model.ikcon(T2, elbow_up_end);
            traj_end = jtraj(current, q_end4, steps);

            % Deletes the position of the brick

            try delete(x);
            catch anything
            end


            for i = 1:steps
                % Calc position of the brick at the end effector

                t = r.model.fkine(traj_end(i,:)).T;
                r.model.animate(traj_end(i,:));

                % Using the logging function provided to us by Gavin
                % message is the x y z of end effector

                matrix = traj_end(i, :);
                endEffector = transl(r.model.fkine(matrix))';
                L.mlog = {L.DEBUG, 'EndEff', endEffector};
                a = 0;

                % Display the end effector position every 10 steps

                if a == mod(i, 10)
                    disp('Current end pos to drop off:')
                    disp(endEffector);
                end

                tip =  r.model.fkine(matrix).T;

                % Displaced by 0.1 in z so the brick appears to be grabbed
                % at the tip of the gripper

                Bpose = tip*transl(0,0,0.1);

                % This moves the brick to the NewPose, multiplies the pose to vertices

                NewPose = [Bpose * [b,ones(Vertex,1)]']';

                % The vertices are all the rows and 1 to 3 columns of the UpdatedPoint

                BrickMove.Vertices = NewPose(:,1:3);
                grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);
                grip.model.animate([pi/12 pi/12]);
                grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                grip2.model.animate([pi/12 pi/12]);
                grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                grip3.model.animate([pi/12 pi/12]);

                % Opens the gripper when endEffector is false

                if endEffector == false
                    grip.model.animate([pi/20 pi/20]);
                    grip2.model.animate([pi/20 pi/20]);
                    grip3.model.animate([pi/20 pi/20]);
                end

                pause(0.02);

            end

            %%

            % For loop 4, moving from up above final to final destination

            % Delete the brick from the up location above the intended
            % destination

            try delete(x);
            catch anything
            end

            % Get the current location, the end location and a translation
            % matrix to transfer the brick to

            current = r.model.getpos();
            % getting a transoformation matrix for the brick and its
            % rotated about the x axis
            T2 = transl(brick_end)*troty(pi);

            steps =100;
            elbow_up_end = deg2rad([0 180 65 50 -35 -50 0]);
            brick_end = r.model.ikcon(T2, elbow_up_end);

            % Setting trajectory of current, brick end, and steps

            traj_end = jtraj(current, brick_end, steps);

            for i = 1:steps

                % Calc position of the brick at the end effector

                t = r.model.fkine(traj_end(i,:)).T;
                r.model.animate(traj_end(i,:));

                %using the logging function provided to us by Gavin
                %message is the x y z of end effector

                matrix = traj_end(i, :);
                endEffector = transl(r.model.fkine(matrix))';
                L.mlog = {L.DEBUG, 'EndEff', endEffector};
                a = 0;

                % Display end effector position at every 10 steps

                if a == mod(i, 10)
                    disp('Current end pos to drop off:')
                    disp(endEffector);
                end

                tip =  r.model.fkine(matrix).T;

                %Displaced by 0.1 in z so bricks appear to be grabbed
                %by the tip of the gripper

                Bpose = tip*transl(0,0,0.1) ;

                %This moves the brick to the NewPose, multiplies the pose to vertices

                NewPose = [Bpose * [b,ones(Vertex,1)]']';

                %The vertices are all the rows and 1 to 3 columns of the UpdatedPoint

                BrickMove.Vertices = NewPose(:,1:3);
                grip.model.base = tip*transl(0,0.01,0)*trotx(pi/2);

                %finger is then animated.

                grip.model.animate([pi/12 pi/12]);
                grip2.model.base = tip*transl(0,-0.015,0)*troty(pi)*trotx(-pi/2);
                grip2.model.animate([pi/12 pi/12]);
                grip3.model.base = tip*transl(0,0.01,0)*troty(pi)*trotx(-pi/2);
                grip3.model.animate([pi/12 pi/12]);

                % Open end claw when endEffector and let go of the brick.

                if endEffector == false

                    grip.model.animate([pi/20 pi/20]);
                    grip2.model.animate([pi/20 pi/20]);
                    grip3.model.animate([pi/20 pi/20]);
                end
                pause(0.02);
            end
        end
        % Function repeats for the 9 bricks.

        function VolCloud()
            r = LinearUR3();

            
            hold on
            VolCloudS = deg2rad(30);
            qlim = r.model.qlim;
            % Don't need to worry about joint 6
            pointCloudeSize = prod(floor((qlim(1:6,2)-qlim(1:6,1))/VolCloudS + 1));
            VolCloud = zeros(pointCloudeSize,3);
            counter = 1;
            tic

            for q1 = qlim(1,1):VolCloudS:qlim(1,2)
                for q2 = qlim(2,1):VolCloudS:qlim(2,2)
                    for q3 = qlim(3,1):VolCloudS:qlim(3,2)
                        for q4 = qlim(4,1):VolCloudS:qlim(4,2)
                            for q5 = qlim(5,1):VolCloudS:qlim(5,2)
                                for q6 = qlim(6,1):VolCloudS:qlim(6,2)
                                    q7 = 0; 
                                    q = [q1,q2,q3,q4,q5,q6,q7];
                                    tr = r.model.fkine(q);
                                    VolCloud(counter,:) = tr(1:3,4)';
                                    counter = counter + 1;
                                    if mod(counter/pointCloudeSize * 100,1) == 0
                                        disp(['After ',num2str(toc),' seconds, completed ',num2str(counter/pointCloudeSize * 100),'% of poses']);
                                    end
                                    %                     end
                                end
                            end
                        end
                    end
                end
            end

            % 2.6 Create a 3D model showing where the end effector can be over all these samples.
            plot3(VolCloud(:,1),VolCloud(:,2),VolCloud(:,3));
        end

    end

end

%{
BACKUP for the grippers
grip.model.base = tip*transl(-0.04,-0.04,0.03)*troty(pi)*trotx(-pi/2);
                grip.model.animate([0 0 0]);
                grip2.model.base = tip*transl(0.04,-0.04,0.03)*troty(pi)*trotx(-pi/2);
                grip2.model.animate([0 0 0]);
                grip3.model.base = tip*transl(0,0.04,0.03)*troty(-pi)*trotx(pi/2);
                grip3.model.animate([0 0 0]);

}%


